#include <iostream>
using namespace std;
#include "Fraction_calculator.h"

int main()
{

    fraction_calculator f;
    f.start();

    return 0;
}
