#ifndef PROBLEM2_FRACTION_CALCULATOR_H
#define PROBLEM2_FRACTION_CALCULATOR_H
#include "Fraction.h"

using namespace std;

class fraction_calculator
{

public:
    fraction_calculator();
    void start();
};

#endif //PROBLEM2_FRACTION_CALCULATOR_H
